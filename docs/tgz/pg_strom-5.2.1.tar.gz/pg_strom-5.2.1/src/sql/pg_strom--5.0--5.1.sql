---
--- PG-Strom v5.0 -> v5.1 (minor changes)
---
ALTER FUNCTION pgstrom.abs(pg_catalog.int1) SET SCHEMA pg_catalog;
