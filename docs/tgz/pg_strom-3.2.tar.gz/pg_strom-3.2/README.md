PG-Strom
========
PG-Strom is an extension for PostgreSQL database.
It is designed to accelerate mostly batch and analytics workloads with
utilization of GPU and NVME-SSD.

For more details, see the documentation below.
http://heterodb.github.io/pg-strom/

Software is fully open source, distributed under GPLv2.


